Licensed under $license license
Copyright $year $owner
